var computerChoice = document.querySelector(".computer-choice");
var userChoice = document.querySelector(".user-choice");
var result = document.querySelector(".result");
var btn =document.querySelectorAll("button")
console.log(btn)
btn.forEach((e)=>{
    e.addEventListener("click",(i)=>{
        // console.log(e.id)
       var userchoicedisplay = i.target.id;
       userChoice.innerHTML = userchoicedisplay;
       generatecomputerchoice();
       generateResult()
    })
})
function generatecomputerchoice(){
    var userchoicearray = ["rock","paper","scissor"];
    var userchoicedisplay = Math.floor(Math.random()*userchoicearray.length)
    computerChoice.innerHTML = userchoicearray[userchoicedisplay];
    console.log(userchoicedisplay)
}
function generateResult(){
    if(computerChoice.innerHTML === userChoice.innerHTML){
        result.innerHTML = "draw";
    }
  if(computerChoice.innerHTML=="rock"&& userChoice.innerHTML=="paper"){
    result.innerHTML = "you lost";

  }
  if(computerChoice.innerHTML=="rock"&& userChoice.innerHTML=="scissor"){
    result.innerHTML = "you lost";

  }
  if(computerChoice.innerHTML=="paper"&& userChoice.innerHTML=="rock"){
    result.innerHTML = "you won";

  }
  if(computerChoice.innerHTML=="paper"&& userChoice.innerHTML=="scissor"){
    result.innerHTML = "you lost";


}
if(computerChoice.innerHTML=="scissor"&& userChoice.innerHTML=="rock"){
    result.innerHTML = "you won";

  }
  if(computerChoice.innerHTML=="scissor"&& userChoice.innerHTML=="paper"){
    result.innerHTML = "you lost";

  }
}


  